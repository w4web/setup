import { FETCH_POST, NEW_POST, SINGLE_POST } from '../actions/types';

const initialState = {
    items: [],
    item: {},
    singlePost: {},
    is_post_loaded: false
}

export default function (state = initialState, action) {

    switch (action.type) {
        case FETCH_POST:
            return {
                ...state,
                items: action.payload
            }

        case SINGLE_POST:
            return {
                ...state,
                singlePost: action.payload,
                is_post_loaded: true
            }

        default:
            return state;
    }

}