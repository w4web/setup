import { LOGIN_INFO } from '../actions/types';
import { LOGOUT } from '../actions/types';

const initialState = {
    userInfo: {}
}

export default function (state = initialState, action) {

    switch (action.type) {
        case LOGIN_INFO:
            return {
                ...state,
                userInfo: action.payload
            }
        case LOGOUT:
            return {
                ...state,
                userInfo: action.payload
            }

        default:
            return state;
    }

}