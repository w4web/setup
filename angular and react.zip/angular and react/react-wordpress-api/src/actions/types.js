export const FETCH_POST = 'FETCH_POST';
export const NEW_POST = 'NEW_POST';
export const SINGLE_POST = 'SINGLE_POST';
export const LOGIN_INFO = 'LOGIN_INFO';
export const LOGOUT = 'LOGOUT';
