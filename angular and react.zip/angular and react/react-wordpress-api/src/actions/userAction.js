import { LOGIN_INFO } from './types';
import { LOGOUT } from './types';

export const userLogin = (loginData) => (dispatch) => {

    fetch('http://localhost/wordpress/wp-json/jwt-auth/v1/token', {
        method: 'POST',
        body: JSON.stringify(loginData),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
    .then(response => response.json())
    .then(json => dispatch({
        type: LOGIN_INFO,
        payload: json
    }))

};

export const logOut = () => (dispatch) => {

    dispatch({
        type: LOGOUT,
        payload: {}
    })

};