import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';
import { fetchPosts, singlePosts } from '../actions/postActions';

class PostList extends Component {

    componentWillMount() {
        this.props.fetchPosts();
    }

    changePostId(postid) {
        this.props.singlePosts(postid);
    }

    render() {

        return (
            <div>
                {console.log(this.props.posts)}
                <div className="list-group">
                    {
                        this.props.posts.map(post => (
                            <Link to="/post-detail" onClick={(e) => this.changePostId(post.id)} key={post.id} className="list-group-item list-group-item-action flex-column align-items-start">
                                <div className="d-flex w-100 justify-content-between">
                                    <h5 className="mb-1">{post.title.rendered}</h5>
                                    <small>Post id: {post.id}</small>
                                </div>
                                <p className="mb-1" dangerouslySetInnerHTML={{__html: post.content.rendered}} ></p>
                            </Link>
                        ))
                    }
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => ({
    posts: state.posts.items
})

export default connect(mapStateToProps, { fetchPosts, singlePosts })(PostList)