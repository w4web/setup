import React, { Component } from 'react';
import { connect } from 'react-redux';
import { logOut } from '../actions/userAction';

import { Redirect } from 'react-router-dom';

class Home extends Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false
    }

  }

  componentDidMount() {

    if(sessionStorage.getItem('userInfo')) {
      console.log ('user logged in');
    } else {
      this.setState({redirect: true});
    }

  }

  logOut() {
    sessionStorage.setItem('userInfo', '');
    sessionStorage.clear();
    this.props.logOut();
    this.setState({redirect: true});
  }

  render() {

    if (this.state.redirect) {
      return ( <Redirect to={'/login'} /> )
    }

    return (
      <div>
        home
        <button onClick={this.logOut.bind(this)} >Logout</button>
      </div>
    )
  }
}

export default connect(null, { logOut })(Home)