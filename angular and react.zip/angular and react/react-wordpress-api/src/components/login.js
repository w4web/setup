import React, { Component } from 'react';
import { connect } from 'react-redux';
import { userLogin } from '../actions/userAction';
import { Redirect } from 'react-router-dom';

class Login extends Component {

  constructor(props) {

    super(props);

    this.state = {
        username: '',
        password: '',
        redirect: false
    }

  }

  onChangeFields(e) {

    const name = e.target.name;
    const value = e.target.value;

    this.setState({
        [name]: value
    });
  }


  onSubmitForm (e) {

    e.preventDefault();

    this.props.userLogin({username: this.state.username, password: this.state.password});

    this.setState({
        username: '',
        password: ''
    });
  }

  componentDidUpdate () {

    console.log(this.props.userInfo);

    if (this.props.userInfo.token) {
        sessionStorage.setItem('userInfo', this.props.userInfo.token);
        this.setState({redirect: true})
    } else {
        console.log('login error');
    }

  }

  render() {

    if (this.state.redirect) {
        return ( <Redirect to={'/'} /> )
    }

    if (sessionStorage.getItem('userInfo')) {
        return ( <Redirect to={'/'} /> )
    }

    return (
      <div>
        <form onSubmit={ this.onSubmitForm.bind(this) }>
          <div className="form-group">
            <label htmlFor="input1">Username</label>
            <input type="text" name="username" value={this.state.username} onChange={this.onChangeFields.bind(this)} className="form-control" id="input1" />
          </div>
          <div className="form-group">
            <label htmlFor="input2">Password</label>
            <input type="password" name="password" value={this.state.password} onChange={this.onChangeFields.bind(this)} className="form-control" id="input2" />
          </div>
          <input type="submit" className="btn btn-primary" value="submit" />
        </form>

      </div>
    )
  }
}

const mapStateToProps = (state) => ({
    userInfo: state.userData.userInfo
})

export default connect(mapStateToProps, { userLogin })(Login)