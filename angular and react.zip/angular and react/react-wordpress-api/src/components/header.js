import React from 'react';
import { Link } from "react-router-dom";

export default function Header() {
    return (
        <div>
            <header>
                <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
                    <ul className="navbar-nav">
                        <li className="nav-item active">
                            <Link className="nav-link" to="/">home</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/post-list">post list</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/add-post">add post</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/login">login</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/register">register</Link>
                        </li>
                    </ul>
                </nav>
            </header>
        </div>
    )
}
