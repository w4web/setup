import React, { Component } from 'react';
import { connect } from 'react-redux';
import { userLogin } from '../actions/userAction';
import { Redirect } from 'react-router-dom';

class Register extends Component {

  constructor(props) {

    super(props);

    this.state = {
        username: '',
        password: '',
        email: '',
        display_name: '',
        redirect: false
    }

  }

  onChangeFields(e) {

    const name = e.target.name;
    const value = e.target.value;

    this.setState({
        [name]: value
    });
  }

  signUpUser(nonce) {
    fetch('http://localhost/wordpress/api/user/register/?insecure=cool&username=' + this.state.username + '&display_name=' + this.state.display_name + '&nonce=' + nonce + '&email=' + this.state.email + '&user_pass=' + encodeURIComponent(this.state.password))
    .then(res => console.log(res.json()))
    .catch(err => console.log(err.response))
  }

  getNonce() {

    fetch('http://localhost/wordpress/api/get_nonce/?controller=user&method=register')
        .then(res => res.json())
        .then(data => this.signUpUser(data.nonce))
        .catch( error => console.log(error.response))

  }


  onSubmitForm (e) {

    e.preventDefault();

    this.getNonce();

    // this.setState({
    //     username: '',
    //     password: '',
    //     email: '',
    //     display_name: ''
    // });
  }

//   componentDidUpdate () {

//     console.log(this.props.userInfo);

//     if (this.props.userInfo.token) {
//         sessionStorage.setItem('userInfo', this.props.userInfo.token);
//         this.setState({redirect: true})
//     } else {
//         console.log('login error');
//     }

//   }

  render() {

    // if (this.state.redirect) {
    //     return ( <Redirect to={'/'} /> )
    // }

    // if (sessionStorage.getItem('userInfo')) {
    //     return ( <Redirect to={'/'} /> )
    // }

    return (
      <div>
        <form onSubmit={ this.onSubmitForm.bind(this) }>
          <div className="form-group">
            <label htmlFor="input1">Username</label>
            <input type="text" name="username" value={this.state.username} onChange={this.onChangeFields.bind(this)} className="form-control" id="input1" />
          </div>
          <div className="form-group">
            <label htmlFor="input2">Password</label>
            <input type="password" name="password" value={this.state.password} onChange={this.onChangeFields.bind(this)} className="form-control" id="input2" />
          </div>
          <div className="form-group">
            <label htmlFor="input3">Email</label>
            <input type="email" name="email" value={this.state.email} onChange={this.onChangeFields.bind(this)} className="form-control" id="input3" />
          </div>
          <div className="form-group">
            <label htmlFor="input4">Display name</label>
            <input type="text" name="display_name" value={this.state.display_name} onChange={this.onChangeFields.bind(this)} className="form-control" id="input4" />
          </div>
          <input type="submit" className="btn btn-primary" value="submit" />
        </form>

      </div>
    )
  }
}

// const mapStateToProps = (state) => ({
//     userInfo: state.userData.userInfo
// })

export default connect(null, { userLogin })(Register)