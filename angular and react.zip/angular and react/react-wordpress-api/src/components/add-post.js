import React, { Component } from 'react';
import { connect } from 'react-redux';
import { newPosts } from '../actions/postActions';

class AddPost extends Component {

  constructor(props) {

    super(props);

    this.state = {
      title: '',
      content: '',
      status: 'publish'
    }

  }

  onChangeTitle(e) {
    this.setState({
      title: e.target.value
    });
  }

  onChangeContent(e) {
    this.setState({
      content: e.target.value
    });
  }

  onSubmitForm (e) {

    e.preventDefault();
    
    const tokenId = sessionStorage.getItem('userInfo');

    this.props.newPosts(this.state, tokenId);
    this.setState({
      title: '',
      content: ''
    });
  }

  render() {
    return (
      <div>
        <form onSubmit={ this.onSubmitForm.bind(this) }>
          <div className="form-group">
            <label htmlFor="exampleInputEmail1">Post Title</label>
            <input type="text" value={this.state.title} onChange={this.onChangeTitle.bind(this)} className="form-control" id="exampleInputEmail1" />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputEmail2">Post content</label>
            <input type="text" value={this.state.content} onChange={this.onChangeContent.bind(this)} className="form-control" id="exampleInputEmail2" />
          </div>
          <input type="submit" className="btn btn-primary" value="submit" />
        </form>
      </div>
    )
  }
}

export default connect(null, { newPosts })(AddPost)