import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route } from "react-router-dom";
import Header from './components/header';
import Home from './components/home';
import Login from './components/login';
import Register from './components/register';
import PostList from './components/post-list';
import PostDetail from './components/post-detail';
import AddPost from './components/add-post';
import store from './store';

export default class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <Router>
          <div className="container">
            <Header />
            <hr />
            <Route path="/" exact component={Home} />
            <Route path="/post-list" component={PostList} />
            <Route path="/post-detail" component={PostDetail} />
            <Route path="/add-post" component={AddPost} />
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
          </div>
        </Router>
      </Provider>
    )
  }
}