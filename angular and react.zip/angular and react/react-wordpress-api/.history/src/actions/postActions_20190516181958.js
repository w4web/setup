import { FETCH_POST, NEW_POST, SINGLE_POST } from './types';

export const fetchPosts = () => (dispatch) => {

    fetch('http://localhost/wordpress/wp-json/wp/v2/posts')
        .then(response => response.json())
        .then(posts => dispatch({
            type: FETCH_POST,
            payload: posts
        }))

};

export const singlePosts = (postid) => (dispatch) => {

    fetch('http://localhost/wordpress/wp-json/wp/v2/posts/' + postid)
        .then(response => response.json())
        .then(post => dispatch({
            type: SINGLE_POST,
            payload: post
        }))

};