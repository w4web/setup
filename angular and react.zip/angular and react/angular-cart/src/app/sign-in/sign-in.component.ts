import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor(private fb: FormBuilder, public commonService: CommonService) { }

  ngOnInit() {
  }

  signForm = this.fb.group({
    type: ['token'],
    email: ['', Validators.required],
    password: ['', Validators.required],
  });

  onSubmit() {
    // console.log(this.signForm.value)
    this.commonService.login(this.signForm.value);
    this.signForm.reset();
  }

}
