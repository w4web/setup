import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  constructor(private fb: FormBuilder, public commonService: CommonService) { }

  profileData: any = {};
  customer_id:any;
  myTab: string = 'tab1';

  ngOnInit() {

    let customer_data_obj = JSON.parse(sessionStorage.getItem('customer_data'));
    this.customer_id = customer_data_obj.customer_id;
    this.commonService.getCustomer(this.customer_id).subscribe(res => this.profileData = res.data);
    this.commonService.getAddresses(this.customer_id);

  }

  tabber(tabString) {

    if (this.myTab !== tabString) {
      this.myTab = tabString;
    }

  }

  myAddress = this.fb.group({
    type: ['', Validators.required],
    first_name: ['', Validators.required],
    last_name: ['', Validators.required],
    phone_number: ['', Validators.required],
    name: ['', Validators.required],
    line_1: ['', Validators.required],
    postcode: ['', Validators.required],
    county: ['', Validators.required],
    country: ['', Validators.required]
  });

  onSubmit() {
    this.commonService.addAddress(this.customer_id, this.myAddress.value);
    this.myAddress.reset();
  }

  deleteAddress(address_id) {
    this.commonService.deleteAddress(this.customer_id, address_id);
  }

}
