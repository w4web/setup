import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public commonService: CommonService) { }

  productData = [];
  productImages = [];

  ngOnInit() {

    this.commonService.access_token();

    // **** getting all products ****
    // console.log('my token', this.commonService.mainAccessToken);

    this.commonService.allProductsData().subscribe(res => {
      this.productData = res.data;
      // console.log('product data', this.productData);
    }, err => console.log(err));

    this.commonService.allProductImages().subscribe(res => {
      res.data.map(single_data => this.productImages.push(single_data.link.href) )
    }, err => console.log(err));

  }

  // **** add to cart ****

  addToCart(cartData) {
    const cartDataObj = {
      "id": cartData,
      "type": "cart_item",
      "quantity": 1
    }
    this.commonService.addToCart(cartDataObj);
  }

}
