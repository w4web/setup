import { Component, OnInit, DoCheck } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, DoCheck {

  constructor(public commonService: CommonService) { }

  cartItemNum: number;

  ngOnInit() {
    this.commonService.getCartItems();
    this.commonService.checkSession();
  }

  ngDoCheck() {
    this.cartItemNum = this.commonService.cartItems.length;
    this.commonService.checkSession();
  }

  logOut() {
    sessionStorage.setItem('customer_data', '');
    sessionStorage.clear();
  }

}
