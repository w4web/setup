import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Router, Resolve} from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient, private router: Router) { }

  // Token Request

  public mainAccessToken: string = '';

  tokenRequestData = "client_id=IpFYhDQ4KlB25M1c2bvZErUiMMUMvrlg4BdGUsX42Z&client_secret=yxjyuWwZaWBx5RUJdSu1rysd1HAC62iG18wR3TBAlk&grant_type=client_credentials";

  tokenHttpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  access_token() {
    this.http.post<any>("https://api.moltin.com/oauth/access_token", this.tokenRequestData, this.tokenHttpOptions)
    .subscribe(data => 
      {
        this.mainAccessToken = data.access_token;
        console.log(data.access_token);
      });
  }

  // ******* Token Request end ********

  commonHttpOptions = {
    // headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.mainAccessToken}` })
    headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': `Bearer 3740ee2a00874415fd50a718cadfbd6018875ce4` })
  };

  // all products data

  allProductsData() :Observable<any> {
    return this.http.get<any>("https://api.moltin.com/v2/products", this.commonHttpOptions)
  }
  allProductImages() :Observable<any> {
    return this.http.get<any>("https://api.moltin.com/v2/files", this.commonHttpOptions)
  }

  // cart

  cartItems = [];
  cartItemsMeta;

  addToCart(data) {
    this.http.post<any>("https://api.moltin.com/v2/carts/ref1/items", {data: data}, this.commonHttpOptions)
    .subscribe(
      res => console.log('cart data', res),
      err => console.log(err),
      () => this.getCartItems()
    )
  }

  getCartItems() {
    this.http.get<any>("https://api.moltin.com/v2/carts/ref1/items", this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('cart all data', res);
        this.cartItems = res.data;
        this.cartItemsMeta = res.meta;
      },
      err => console.log(err)
    )
  }

  DeleteCartItems(itemId) {
    this.http.delete<any>(`https://api.moltin.com/v2/carts/ref1/items/${itemId}`, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('after delete cart item', res);
      },
      err => console.log(err),
      () => this.getCartItems()
    )
  }

  // checkout

  checkout(data) {
    this.http.post<any>("https://api.moltin.com/v2/carts/ref1/checkout", {data: data}, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('after checkout data', res);
        this.order_id = res.data.id;
      },
      err => console.log(err),
      () => {
        this.payment();
        this.DeleteCart();
      }
    )
  }

  DeleteCart() {
    this.http.delete<any>("https://api.moltin.com/v2/carts/ref1", this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('after delete full cart', res);
      },
      err => console.log(err),
      () => this.getCartItems()
    )
  }

  // Payment

  order_id:any = "";

  pay_data = {
    "gateway": "stripe",
    "method": "purchase",
    "payment": "tok_visa"
  }

  payment() {
    this.http.post<any>(`https://api.moltin.com/v2/orders/${this.order_id}/payments`, {data: this.pay_data}, this.commonHttpOptions)
    .subscribe(
      res => console.log('after payment data', res),
      err => console.log(err)
    )
  }

  // customer

  errorMsg: string = '';
  successMsg: string = '';

  hadleError(errDtata) {
    if(errDtata.status == 409) {
      this.errorMsg = 'Email address is already available.';
    }
  }

  create_customer(data) {
    this.http.post<any>("https://api.moltin.com/v2/customers", {data: data}, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('Customer added data', res);
      },
      err => {
        this.hadleError(err);
      },
      () => {
        console.log('Customer added successfully...');
        this.successMsg = 'Customer added successfully...';
      }
    )
  }

  login(data) {
    this.http.post<any>("https://api.moltin.com/v2/customers/tokens", {data: data}, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('Customer login data', res);
        sessionStorage.setItem('customer_data', JSON.stringify(res.data));
      },
      err => console.log(err),
      () => {
        console.log('Customer login successfully...');
        this.router.navigate(['/']);
      }
    )
  }

  is_logged_in:boolean = false;

  checkSession() {

    let customer_data_obj = JSON.parse(sessionStorage.getItem('customer_data'));

    if(customer_data_obj !== null) {
      if(customer_data_obj.token !== '') {
        // console.log('token on profile page', customer_data_obj.token);
        this.is_logged_in = true;
      } else {
        this.is_logged_in = false;
      }
    } else {
      this.is_logged_in = false;
    }

  }

  logOut() {
    sessionStorage.setItem('customer_data', '');
    sessionStorage.clear();
  }

  // my profile API calls

  getCustomer(id) :Observable<any> {
    return this.http.get<any>(`https://api.moltin.com/v2/customers/${id}`, this.commonHttpOptions)
  }

  addAddress(customerId, data) {
    this.http.post<any>(`https://api.moltin.com/v2/customers/${customerId}/addresses`, {data: data}, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('address is added', res);
      },
      err => console.log(err),
      () => {
        console.log('address is added successfully...');
        this.getAddresses(customerId);
      }
    )
  }

  myAddresses: any = [];

  getAddresses(id) {
    this.http.get<any>(`https://api.moltin.com/v2/customers/${id}/addresses`, this.commonHttpOptions).subscribe(res => this.myAddresses = res.data);
  }

  deleteAddress(customer_id, address_id) {
    this.http.delete<any>(`https://api.moltin.com/v2/customers/${customer_id}/addresses/${address_id}`, this.commonHttpOptions)
    .subscribe(
      res => {
        console.log('after delete address', res);
      },
      err => console.log(err),
      () => this.getAddresses(customer_id)
    )
  }

}
