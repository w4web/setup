import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor(private fb: FormBuilder, public commonService: CommonService) { }

  loginData = {
    type: 'customer',
    name: '',
    email: '',
    password: ''
  }

  ngOnInit() {
  }

  signForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
  });

  onSubmit() {
    
    this.loginData.name = this.signForm.value.name;
    this.loginData.email = this.signForm.value.email;
    this.loginData.password = this.signForm.value.password;

    this.commonService.create_customer(this.loginData);
    this.signForm.reset();
  }

}
