import { Component, OnInit, DoCheck } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit, DoCheck {

  checkoutData = {
    customer: {},
    billing_address: {},
    shipping_address: {}
  }

  // for logged in customer

  profileData: any = {};
  customer_id: any;
  checkoutDataAfterLogin: any = {};

  constructor(private fb: FormBuilder, public commonService: CommonService) { }

  ngOnInit() {

    // for logged in customer

    if (this.commonService.is_logged_in == true) {

      let customer_data_obj = JSON.parse(sessionStorage.getItem('customer_data'));
      this.customer_id = customer_data_obj.customer_id;
      this.commonService.getCustomer(this.customer_id).subscribe(res => this.profileData = res.data);
      this.commonService.getAddresses(this.customer_id);

    }

  }

  ngDoCheck() {
    if (this.commonService.myAddresses.length !== 0) {
      this.checkoutDataAfterLogin = {
        customer: {
          id: this.customer_id
        },
        shipping_address: {
          first_name: this.commonService.myAddresses[0].first_name,
          last_name: this.commonService.myAddresses[0].last_name,
          line_1: this.commonService.myAddresses[0].line_1,
          phone_number: this.commonService.myAddresses[0].phone_number,
          postcode: this.commonService.myAddresses[0].postcode,
          county: this.commonService.myAddresses[0].county,
          country: this.commonService.myAddresses[0].country,
        },
        billing_address: {
          first_name: this.commonService.myAddresses[1].first_name,
          last_name: this.commonService.myAddresses[1].last_name,
          line_1: this.commonService.myAddresses[1].line_1,
          postcode: this.commonService.myAddresses[1].postcode,
          county: this.commonService.myAddresses[1].county,
          country: this.commonService.myAddresses[1].country,
        }
      }
    }
  }

  ckForm = this.fb.group({
    customer: this.fb.group({
      email: ['', Validators.required],
      name: ['', Validators.required],
    }),
    billing_address: this.fb.group({
      first_name: ['', Validators.required],
      last_name: ['', Validators.required],
      line_1: ['', Validators.required],
      postcode: ['', Validators.required],
      county: ['', Validators.required],
      country: ['', Validators.required]
    }),
  });

  onSubmit() {
    this.checkoutData.customer = this.ckForm.value.customer;
    this.checkoutData.billing_address = this.ckForm.value.billing_address;
    this.checkoutData.shipping_address = this.ckForm.value.billing_address;
    console.log(this.checkoutData);
    this.commonService.checkout(this.checkoutData);
  }

  onSubmitAfterLogin() {
    this.commonService.checkout(this.checkoutDataAfterLogin);
  }

}
