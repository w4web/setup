const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const multer = require('multer');

const adminRoutes = require('./routes/admin-route');
const shopRoutes = require('./routes/shop-route');
const crossOrigin = require('./util/cross-origin');
const imageUpload = require('./util/image-upload');
const connection = 'mongodb+srv://admin:fCPzBtIcvZIXGahE@mycluster.edbav.mongodb.net/product?retryWrites=true&w=majority';

// mongodb+srv://admin:fCPzBtIcvZIXGahE@mycluster.edbav.mongodb.net/test

const server = express();
server.use(bodyParser.json()); 
server.use(express.static(path.join(__dirname, 'public')));
server.use('/images', express.static(path.join(__dirname, 'images')));

// multer

server.use(multer({ storage: imageUpload.fileStorage, fileFilter: imageUpload.fileFilter }).single('image'));

// Router

server.use('/admin', adminRoutes);
server.use(shopRoutes);

// Cross origin

server.use(crossOrigin.allowCrossOrigin);

// Database connection

mongoose.connect(connection).then(result => {server.listen(8080, '192.168.15.122');}).catch(err => console.log(err));