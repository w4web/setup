const express = require('express');
const path = require('path');

const adminController = require('../controllers/admin-controller');
const fileUploadController = require('../controllers/fileUpload-controller');

const router = express.Router();

router.post('/uploadFile', fileUploadController.uploadFile);

router.get('/product', adminController.getProducts);

router.post('/add-product', adminController.addProduct);

module.exports = router;