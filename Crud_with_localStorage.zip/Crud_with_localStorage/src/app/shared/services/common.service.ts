import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  allContacts = [];

  constructor() { 
    this.getContacts();
  }

  addContact(data) {
    this.allContacts.push(data);
    localStorage.setItem('data', JSON.stringify(this.allContacts));
  }

  getContacts() {
    if (localStorage.getItem("data") !== null) {
      this.allContacts = JSON.parse(localStorage.getItem('data'));
    }
  }

}
