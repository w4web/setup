import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactsRoutingModule } from './contacts-routing.module';
import { ContactsComponent } from './contacts.component';
import { ContactListComponent } from './contact-list/contact-list.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { EditContactComponent } from './edit-contact/edit-contact.component';
import {DpDatePickerModule} from 'ng2-date-picker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ContactListComponent,
    AddContactComponent,
    EditContactComponent,
    ContactsComponent
  ],
  imports: [
    CommonModule,
    ContactsRoutingModule,
    DpDatePickerModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ContactsModule { }
