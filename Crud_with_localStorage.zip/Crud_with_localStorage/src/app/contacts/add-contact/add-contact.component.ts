import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, Resolve } from '@angular/router';
import { CommonService } from '../../shared/services/common.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.scss']
})
export class AddContactComponent implements OnInit {

  constructor(public commonService: CommonService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
  }

  addContact = {
    name: '',
    contact: '',
    email: '',
    notes: ''
  }

  addContactForm = this.formBuilder.group({
    name: ['', Validators.required],
    contact: ['', Validators.required],
    email: ['', Validators.required],
    notes: ['', Validators.required]
  });

  onSubmit() {

    this.addContact.name = this.addContactForm.value.name;
    this.addContact.contact = this.addContactForm.value.contact;
    this.addContact.email = this.addContactForm.value.email;
    this.addContact.notes = this.addContactForm.value.notes;

    this.commonService.addContact(this.addContact);
    this.addContactForm.reset();
  }

}
