import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from '../shared/components/page-not-found/page-not-found.component';

import { AddContactComponent } from './add-contact/add-contact.component';
import { ContactListComponent } from './contact-list/contact-list.component';
import { ContactsComponent } from './contacts.component';
import { EditContactComponent } from './edit-contact/edit-contact.component';

const routes: Routes = [
  {
    path: '',
    component: ContactsComponent,
    children: [
      { path: '', redirectTo: 'contact-list', pathMatch: 'full' },
      { path: 'contact-list', component: ContactListComponent },
      { path: 'add-contact', component: AddContactComponent },
      { path: 'edit-contact/:id', component: EditContactComponent },
      { path: '**', component: PageNotFoundComponent }
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContactsRoutingModule {}
