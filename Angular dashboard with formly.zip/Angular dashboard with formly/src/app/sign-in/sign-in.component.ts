import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyFormOptions, FormlyFieldConfig } from '@ngx-formly/core';
import { Router } from '@angular/router';
import { ProfileService } from '../shared/services/profile.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {

  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[];

  constructor(private router: Router, public profileService: ProfileService) {

    this.profileService.getLoginFields().subscribe(fields => {
      this.form = new FormGroup({});
      this.fields = fields;
    })

  }

  ngOnInit(): void {}

  submit() {
    console.log(JSON.stringify(this.model));
    this.router.navigateByUrl('/dashboard');
  }

}
