export const sidebarData = [
    {
      title: 'Dashboard',
      link: 'home',
      icon: 'fa fa-dashboard',
      isChild: false
    },
    {
      title: 'Components',
      link: 'home',
      icon: 'fa fa-puzzle-piece',
      isChild: false
    },
    {
      title: 'Extras',
      link: 'home',
      icon: 'fa fa-heart',
      isChild: false
    },
    {
      title: 'Apps',
      link: 'home',
      icon: 'fa fa-diamond',
      isChild: true,
      children: [
        {
          title: 'Mail',
          link: 'home',
          isChild: false
        },
        {
          title: 'Calendar',
          link: 'home',
          isChild: false
        },
        {
          title: 'Ecommerce',
          link: 'home',
          isChild: false
        },
        {
          title: 'User',
          link: 'home',
          isChild: false
        },
        {
          title: 'Social',
          link: 'home',
          isChild: false
        },
        {
          title: 'Sub Level',
          link: 'home',
          isChild: true,
          children: [
            {
              title: 'Link1',
              link: 'home',
              isChild: false
            },
            {
              title: 'Link2',
              link: 'home',
              isChild: false
            },
            {
              title: 'Link3',
              link: 'home',
              isChild: false
            }
          ]
        }
      ]
    },
    {
      title: 'Link',
      link: 'home',
      icon: 'fa fa-signal',
      isChild: true,
      children: [
        {
          title: 'Link1',
          link: 'home',
          isChild: false
        },
        {
          title: 'Link2',
          link: 'home',
          isChild: false
        },
        {
          title: 'Link3',
          link: 'home',
          isChild: false
        }
      ]
    }
  ]