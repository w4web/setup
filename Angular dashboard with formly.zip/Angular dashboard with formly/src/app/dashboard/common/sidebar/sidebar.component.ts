import { Component, OnInit } from '@angular/core';
import { sidebarData } from './sidebarData';
import {
  AUTO_STYLE,
  animate,
  state,
  style,
  transition,
  trigger
} from '@angular/animations';
import { CommonService } from 'src/app/shared/services/common.service';

const DEFAULT_DURATION = 300;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  animations: [
    trigger('collapse', [
      state('true', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
      state('false', style({ height: '0', visibility: 'hidden' })),
      transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
      transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
    ])
  ]
})
export class SidebarComponent implements OnInit {

  public sidebarData;

  public level1 = '';
  public level2 = '';

  onToggle(text) {
    if(this.level1 == text) {
      this.level1 = '';
    } else {
      this.level1 = text;
    }
  }

  onToggle2(text) {
    if(this.level2 == text) {
      this.level2 = '';
    } else {
      this.level2 = text;
    }
  }

  closeSidebar() {
    if(window.innerWidth < 1024) {
      this.commonService.isShow = false;
    }
  }

  constructor( public commonService: CommonService ) { }

  ngOnInit(): void {

    this.sidebarData = sidebarData;

    if(window.innerWidth < 1024) {
      this.commonService.isShow = false;
    }

  }

}
