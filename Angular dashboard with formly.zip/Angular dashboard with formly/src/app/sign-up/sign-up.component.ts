import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FormlyFormOptions, FormlyFieldConfig } from '@ngx-formly/core';
import { ProfileService } from '../shared/services/profile.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  form = new FormGroup({});
  model: any = {};
  options: FormlyFormOptions = {};
  fields: FormlyFieldConfig[];

  constructor(private router: Router, public profileService: ProfileService) {

    this.profileService.getRegisterFields().subscribe(fields => {
      this.form = new FormGroup({});
      this.fields = fields;
    })

  }

  ngOnInit(): void {}

  submit() {
    console.log(JSON.stringify(this.model));
    this.router.navigateByUrl('/dashboard');
  }

}
