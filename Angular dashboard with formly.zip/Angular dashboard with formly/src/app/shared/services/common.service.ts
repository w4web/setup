import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  public isShow: boolean = true;
  public isDark: boolean = false;

  constructor() {
    this.checkThemeStatus();
  }

  checkThemeStatus() {
    if (localStorage.getItem('ThemeStatus') == undefined) {
      localStorage.setItem('ThemeStatus', 'false');
      this.isDark = false;
    }
    if (localStorage.getItem('ThemeStatus') == 'true') {
      this.isDark = true;
    } else {
      this.isDark = false;
    }
  }

  toLight() {
    localStorage.setItem('ThemeStatus', 'false');
    this.checkThemeStatus();
  }

  toDark() {
    localStorage.setItem('ThemeStatus', 'true');
    this.checkThemeStatus();
  }
}
