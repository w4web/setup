import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';

@NgModule({
  declarations: [PageNotFoundComponent],
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    FormlyBootstrapModule
  ],
  exports: [
    PageNotFoundComponent,
    NgbModule,
    ReactiveFormsModule,
    FormlyBootstrapModule
  ]
})
export class SharedModule { }
