<div class="preview-wrap">
    <div class="preview-inner front-view active">
        <div style="z-index: 1;" class="part sleeve">
            <?php include "svg/sleeve.php" ?>
        </div>

        <div style="z-index: 2;" class="part body">
            <?php include "svg/body.php" ?>
        </div>

        <div style="z-index: 3;" class="part collars">
            <div class="collar-inner collar-inner-1 active"><?php include "svg/collars/collar-knit.php" ?></div>
            <div class="collar-inner collar-inner-2"><?php include "svg/collars/collar-wool.php" ?></div>
            <div class="collar-inner collar-inner-3"><?php include "svg/collars/collar-zippered.php" ?></div>
        </div>

        <div style="z-index: 4;" class="part bottom">
            <?php include "svg/bottom.php" ?>
        </div>

        <!-- shadow Images -->

        <img class="shadow-img" style="z-index: 10;" src="images/jacket-trans.png" alt="img" />

        <img class="shadow-img collar-shadow collar-shadow-1 active" style="z-index: 10;" src="images/collar-knit-trans.png" alt="img" />
        <img class="shadow-img collar-shadow collar-shadow-2" style="z-index: 10;" src="images/collar-wool-trans.png" alt="img" />
        <img class="shadow-img collar-shadow collar-shadow-3" style="z-index: 10;" src="images/collar-zippered-trans.png" alt="img" />

        <img class="shadow-img" style="z-index: 10;" src="images/bottom-trans.png" alt="img" />

        <!-- shadow Images end -->

        <!-- <div class="yourNameTest-wrap">
            <span class="yourNameTest"></span>
        </div>

        <div class="logoWrao">
        <?php //include "svg/logo.php" 
        ?>
        </div> -->
    </div>

    <div class="preview-inner Left-view">
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
    </div>
    <div class="preview-inner Back-view">Lorem ipsum dolor sit amet consectetur adipisicing elit.</div>
    <div class="preview-inner Right-view">Lorem ipsum dolor sit amet consectetur adipisicing elit.</div>

</div>

<div class="side-options">
    <div class="row">
        <div class="col-lg-3">
            <button class="btn btn-dark btn-block">Front view</button>
        </div>
        <div class="col-lg-3">
            <button class="btn btn-dark btn-block">Left view</button>
        </div>
        <div class="col-lg-3">
            <button class="btn btn-dark btn-block">Back view</button>
        </div>
        <div class="col-lg-3">
            <button class="btn btn-dark btn-block">Right view</button>
        </div>
    </div>
</div>