<!-- <footer class="secondaryBg">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 footer-col-1">

			</div>
			<div class="col-lg-4 footer-col-2">
				
			</div>
			<div class="col-lg-3 footer-col-3">
				
			</div>
		</div>
		<div class="copyright">© Plaid Consulting 2020 | <a href="#">Privacy policy</a></div>
	</div>
</footer> -->

</div>

<!-- javascript libraries -->

<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js"></script>

<script src="js/opt_ajax.js"></script>

<script src="js/bootstrap.min.js"></script>
<script src="js/menu.js"></script>
<script src="js/accordion.js"></script>
<script src="js/opt_preview.js"></script>

</body>

</html>