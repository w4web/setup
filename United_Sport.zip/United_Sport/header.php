<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/master.css">
	<link rel="icon" href="images/favicon.ico" type="image/ico" sizes="16x16">
	<title>United Sport</title>
</head>

<body>

	<div class="wrapper">

		<!-- <header id="header">
			<div class="container">
				<div class="header-inner">
					<div class="row align-items-center">
						<div class="col-md-3 col-6">
							<div class="main-logo">
								<a href="index.php">
									<img src="images/logo.webp" alt="img" />
								</a>
							</div>
						</div>
						<div class="col-md-9 col-6 main-menu-outer">
							<a class="menu-handler" href="javascript:void(0);">
								<span></span>
								<span></span>
								<span></span>
							</a>
							<ul class="main-menu clearfix">
								<li><a href="Services.php">Services</a></li>
								<li><a href="partners.php">Partners</a></li>
								<li><a href="caseStudies.php">Case studies</a></li>
								<li><a href="about.php">About</a></li>
								<li><a href="learningResources.php" class="btn btn-outline-primary">Learning</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</header> -->