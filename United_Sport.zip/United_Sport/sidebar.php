<div id="accordion">
    <div class="card acc_card">
        <div class="card-header">
            Sleeve Style
        </div>

        <div id="Acc1" class="collapse" data-parent="#accordion">
            <div class="card-body">

                <div id="st-parent" class="row opt-row align-items-end">
                    <div class="col-lg-9">
                        <h6>Choose Your Sleeve Type</h6>
                        <span class="opt-item">
                            <input type="radio" class="theme-rdo sleeve-type-rdo" value="Leather" name="sleeveType" id="sleeveType1">
                            <label for="sleeveType1" class="btn btn-dark btn-73">Leather</label>
                        </span>
                        <span class="opt-item">
                            <input type="radio" class="theme-rdo sleeve-type-rdo" value="Wool" name="sleeveType" id="sleeveType2">
                            <label for="sleeveType2" class="btn btn-dark btn-73">Wool</label>
                        </span>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button id="fistBack" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button id="stNext1" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>

                <div id="st-level-1-1" class="st-level-1">
                    <div class="row opt-row align-items-end">
                        <div class="col-lg-9">
                            <h6>Choose Your Sleeve Option</h6>
                            <span class="opt-item">
                                <input type="radio" class="theme-rdo" value="Raglan" name="sleeveOption" id="sleeveOption1">
                                <label for="sleeveOption1" class="btn btn-dark btn-73">Raglan</label>
                            </span>
                            <span class="opt-item">
                                <input type="radio" class="theme-rdo" value="Classic" name="sleeveOption" id="sleeveOption2">
                                <label for="sleeveOption2" class="btn btn-dark btn-73">Classic</label>
                            </span>
                        </div>
                        <div class="col-lg-3 pl-0">
                            <button class="btn btn-success btn-sm btn-block stBack">Back</button>
                            <button data-toggle="collapse" data-target="#Acc2" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                        </div>
                    </div>
                </div>
                <div id="st-level-1-2" class="st-level-1">
                    <div class="row opt-row align-items-end">
                        <div class="col-lg-9">
                            <h6>Choose Your Sleeve Option</h6>
                            <span class="opt-item">
                                <input type="radio" class="theme-rdo wool-opt-rdo" value="Same" name="sleeveOption1" id="sleeveOption3">
                                <label for="sleeveOption3" class="btn btn-dark btn-sm btn-73">Same Color as Body</label>
                            </span>
                            <span class="opt-item">
                                <input type="radio" class="theme-rdo wool-opt-rdo" value="Different" name="sleeveOption1" id="sleeveOption4">
                                <label for="sleeveOption4" class="btn btn-dark btn-sm btn-73">Different Color Sleeve</label>
                            </span>
                        </div>
                        <div class="col-lg-3 pl-0">
                            <button class="btn btn-success btn-sm btn-block stBack">Back</button>
                            <button id="stNext2" data-toggle="collapse" data-target="#Acc3" class="btn btn-primary btn-sm btn-block btnNext">Next</button>
                            <button id="stNext3" style="display: none;" data-toggle="collapse" data-target="#Acc2" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            Sleeve Color
        </div>
        <div id="Acc2" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div class="row opt-row">
                    <div class="col-lg-9">
                        <div class="common-color-options sleeve-color-options">
                            <!-- Ajax here -->
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button data-toggle="collapse" data-target="#Acc1" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button data-toggle="collapse" data-target="#Acc3" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            Body Color
        </div>
        <div id="Acc3" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div class="row opt-row">
                    <div class="col-lg-9">
                        <div class="common-color-options body-color-options">
                            <!-- Ajax here -->
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button data-toggle="collapse" data-target="#Acc2" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button data-toggle="collapse" data-target="#Acc4" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            Collar style
        </div>
        <div id="Acc4" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div id="cs-parent" class="row opt-row align-items-end">
                    <div class="col-lg-9">
                        <h6>Pick Your Collar Style Type</h6>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Knit" name="collarStyle" id="collarStyle1">
                            <label for="collarStyle1" class="btn btn-dark btn-35">Knit</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Sport" name="collarStyle" id="collarStyle2">
                            <label for="collarStyle2" class="btn btn-dark btn-35">Sport</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Zippered" name="collarStyle" id="collarStyle3">
                            <label for="collarStyle3" class="btn btn-dark btn-35">Zippered</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Sailor" name="collarStyle" id="collarStyle4">
                            <label for="collarStyle4" class="btn btn-dark btn-35">Sailor</label>
                        </span>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button data-toggle="collapse" data-target="#Acc3" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button id="csNext1" data-toggle="collapse" data-target="#Acc5" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                        <button style="display: none;" id="csNext2" class="btn btn-primary btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>

                <div id="cs-level-1-1" class="inner-option-wrap cs-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Pick Your Undercollar</h6>
                                <span class="opt-item mb-1">
                                    <input type="radio" class="theme-rdo uc-opt-rdo" value="Same" name="UndercollarType" id="UndercollarType1">
                                    <label for="UndercollarType1" class="btn btn-dark btn-sm btn-35">Same Color</label>
                                </span>
                                <span class="opt-item mb-1">
                                    <input type="radio" class="theme-rdo uc-opt-rdo" value="Leather" name="UndercollarType" id="UndercollarType2">
                                    <label for="UndercollarType2" class="btn btn-dark btn-sm btn-35">Leather</label>
                                </span>
                                <span class="opt-item mb-1">
                                    <input type="radio" class="theme-rdo uc-opt-rdo" value="Alternate" name="UndercollarType" id="UndercollarType3">
                                    <label for="UndercollarType3" class="btn btn-dark btn-sm btn-35">Alternate Wool</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block csBack">Back</button>
                                <button id="ucNext1" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                                <button style="display: none;" id="ucNext2" class="btn btn-primary btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Undercollar Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options undercollar-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc5" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="cs-level-1-2" class="inner-option-wrap cs-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Hood Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options hood-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block csBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc5" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="cs-level-1-3" class="inner-option-wrap cs-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Hood Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options s-hood-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block csBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Braid Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options braid-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc5" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card acc_card">
        <div class="card-header">
            Trim Pattern
        </div>
        <div id="Acc5" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div id="tp-parent" class="row opt-row align-items-end">
                    <div class="col-lg-9">
                        <h6>Choose Your Knit Pattern</h6>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo trim-pattern-rdo" value="none" name="trimPattern" id="trimPattern1">
                            <label for="trimPattern1" class="btn btn-dark btn-73"></label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo trim-pattern-rdo" value="striped" name="trimPattern" id="trimPattern2">
                            <label for="trimPattern2" class="btn btn-dark btn-73 bg-striped"></label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo trim-pattern-rdo" value="feathered" name="trimPattern" id="trimPattern3">
                            <label for="trimPattern3" class="btn btn-dark btn-73 bg-feathered"></label>
                        </span>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button data-toggle="collapse" data-target="#Acc4" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button id="tpNext1" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>

                <div id="tp-level-1-1" class="inner-option-wrap tp-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Base Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options base-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block tpBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc6" class="btn btn-success btn-sm btn-block btnNext isWool">Next</button>
                                <button style="display: none;" data-toggle="collapse" data-target="#Acc7" class="btn btn-success btn-sm btn-block btnNext noWool">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tp-level-1-2" class="inner-option-wrap tp-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Base Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options base2-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block tpBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Stripe Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options stripe1-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc6" class="btn btn-success btn-sm btn-block btnNext isWool">Next</button>
                                <button style="display: none;" data-toggle="collapse" data-target="#Acc7" class="btn btn-success btn-sm btn-block btnNext noWool">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tp-level-1-3" class="inner-option-wrap tp-level-1">
                    <div class="inner-option active">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Base Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options base3-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block tpBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Stripe Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options stripe2-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc6" class="btn btn-success btn-sm btn-block btnNext isWool">Next</button>
                                <button style="display: none;" data-toggle="collapse" data-target="#Acc7" class="btn btn-success btn-sm btn-block btnNext noWool">Next</button>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <div class="card acc_card">
        <div class="card-header">
            Shoulder Stripes
        </div>
        <div id="Acc6" class="collapse show" data-parent="#accordion">
            <div class="card-body">
                <div class="inner-option-wrap">
                    <div class="inner-option active">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Stripe Option</h6>
                                <span class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo shoulder-stripes-rdo" value="none" name="ssopt" id="ssopt">
                                    <label for="ssopt" class="btn btn-dark btn-sm btn-73">No Stripes</label>
                                </span>
                                <span class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo shoulder-stripes-rdo" value="Leather" name="ssopt" id="ssopt1">
                                    <label for="ssopt1" class="btn btn-dark btn-sm btn-73">Leather Stripes</label>
                                </span>
                                <span class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo shoulder-stripes-rdo" value="Wool" name="ssopt" id="ssopt2">
                                    <label for="ssopt2" class="btn btn-dark btn-sm btn-73">Wool Stripes</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button data-toggle="collapse" data-target="#Acc5" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                                <button id="ssoNext1" data-toggle="collapse" data-target="#Acc7" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                                <button id="ssoNext2" style="display: none;" class="btn btn-primary btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Stripe Count</h6>
                                <span class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo ssc-rdo" value="1" name="sscOpt" id="sscOpt1">
                                    <label for="sscOpt1" class="btn btn-dark btn-sm btn-73">1 Stripe</label>
                                </span>
                                <span class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo ssc-rdo" value="2" name="sscOpt" id="sscOpt2">
                                    <label for="sscOpt2" class="btn btn-dark btn-sm btn-73">2 Stripe</label>
                                </span>
                                <span id="sscItem3" class="opt-item mt-1">
                                    <input type="radio" class="theme-rdo ssc-rdo" value="3" name="sscOpt" id="sscOpt3">
                                    <label for="sscOpt3" class="btn btn-dark btn-sm btn-73">3 Stripe</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button id="sscNext" class="btn btn-primary btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your First Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options ss1-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block innerNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row">
                            <div class="col-lg-12">
                                <h6>Pick Your Second Color</h6>
                            </div>
                            <div class="col-lg-9">
                                <div class="common-color-options ss2-color-options">
                                    <!-- Ajax here -->
                                </div>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block innerBack">Back</button>
                                <button data-toggle="collapse" data-target="#Acc7" class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

</div>