<div id="accordion">
    <div class="card acc_card">
        <div class="card-header">

            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc1">
                1
            </button> Sleeve Style

        </div>

        <div id="Acc1" class="collapse show" data-parent="#accordion">
            <div class="card-body">
                <div class="row align-items-end">
                    <div class="col-lg-9">
                        <div class="inner-option-wrap">
                            <div class="inner-option active">
                                <h6>Choose Your Sleeve Type</h6>
                                <button class="btn btn-dark btn-50-73">Leather</button>
                                <button class="btn btn-dark btn-50-73">Wool</button>
                            </div>
                            <div class="inner-option">
                                <h6>Choose Your Sleeve Option</h6>
                                <button class="btn btn-dark btn-50-73">Raglan</button>
                                <button class="btn btn-dark btn-50-73">Classic</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button id="fistBack" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc2">
                2
            </button> Sleeve Color
        </div>
        <div id="Acc2" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="common-color-options">
                            <span class="color-option">
                                <input type="radio" value="#20552f" name="colorOptions" id="colorOpt1">
                                <label style="background-color: #20552f;" for="colorOpt1"></label>
                            </span>
                            <span class="color-option">
                                <input type="radio" value="#bb4733" name="colorOptions" id="colorOpt2">
                                <label style="background-color: #bb4733;" for="colorOpt2"></label>
                            </span>
                            <span class="color-option">
                                <input type="radio" value="#c1bd7d" name="colorOptions" id="colorOpt3">
                                <label style="background-color: #c1bd7d;" for="colorOpt3"></label>
                            </span>
                            <span class="color-option">
                                <input type="radio" value="#000000" name="colorOptions" id="colorOpt4">
                                <label style="background-color: #000000;" for="colorOpt4"></label>
                            </span>
                            <span class="color-option">
                                <input type="radio" value="#4e7e84" name="colorOptions" id="colorOpt5">
                                <label style="background-color: #4e7e84;" for="colorOpt5"></label>
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>