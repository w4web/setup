<div id="accordion">
    <div class="card acc_card">
        <div class="card-header">

            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc1">
                1
            </button> Sleeve Style

        </div>

        <div id="Acc1" class="collapse" data-parent="#accordion">
            <div class="card-body">

                <div class="inner-option-wrap">
                    <div class="inner-option active">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Sleeve Type</h6>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveType" id="sleeveType1">
                                    <label for="sleeveType1" class="btn btn-dark btn-73">Leather</label>
                                </span>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveType" id="sleeveType2">
                                    <label for="sleeveType2" class="btn btn-dark btn-73">Wool</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button id="fistBack" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Sleeve Option</h6>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveOption" id="sleeveOption1">
                                    <label for="sleeveOption1" class="btn btn-dark btn-73">Raglan</label>
                                </span>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveOption" id="sleeveOption2">
                                    <label for="sleeveOption2" class="btn btn-dark btn-73">Classic</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc2">
                2
            </button> Sleeve Color
        </div>
        <div id="Acc2" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div class="row opt-row">
                    <div class="col-lg-9">
                        <div class="common-color-options sleeve-color-options">
                            <!-- Ajax here -->
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc3">
                3
            </button> Body Color
        </div>
        <div id="Acc3" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <div class="row opt-row">
                    <div class="col-lg-9">
                        <div class="common-color-options body-color-options">
                            <!-- Ajax here -->
                        </div>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card acc_card">
        <div class="card-header">
            <button class="btn-hidden btnTrigger" data-toggle="collapse" data-target="#Acc4">
                4
            </button> Collar style
        </div>
        <div id="Acc4" class="collapse show" data-parent="#accordion">
            <div class="card-body">
                <div class="row opt-row align-items-end">
                    <div class="col-lg-9">
                        <h6>Pick Your Collar Style Type</h6>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Knit" name="collarStyle" id="collarStyle1">
                            <label for="collarStyle1" class="btn btn-dark btn-35">Knit</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Sport" name="collarStyle" id="collarStyle2">
                            <label for="collarStyle2" class="btn btn-dark btn-35">Sport</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Zippered" name="collarStyle" id="collarStyle3">
                            <label for="collarStyle3" class="btn btn-dark btn-35">Zippered</label>
                        </span>
                        <span class="opt-item mt-1">
                            <input type="radio" class="theme-rdo collar-style-rdo" value="Sailor" name="collarStyle" id="collarStyle4">
                            <label for="collarStyle4" class="btn btn-dark btn-35">Sailor</label>
                        </span>
                    </div>
                    <div class="col-lg-3 pl-0">
                        <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                        <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                        <button class="btn btn-primary btn-sm btn-block csNext">Next</button>
                    </div>
                </div>



                <div class="inner-option-wrap">
                    <div class="inner-option active">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Sleeve Type</h6>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveType" id="sleeveType1">
                                    <label for="sleeveType1" class="btn btn-dark btn-73">Leather</label>
                                </span>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveType" id="sleeveType2">
                                    <label for="sleeveType2" class="btn btn-dark btn-73">Wool</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button id="fistBack" class="btn btn-success btn-sm btn-block btnBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                    <div class="inner-option">
                        <div class="row opt-row align-items-end">
                            <div class="col-lg-9">
                                <h6>Choose Your Sleeve Option</h6>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveOption" id="sleeveOption1">
                                    <label for="sleeveOption1" class="btn btn-dark btn-73">Raglan</label>
                                </span>
                                <span class="opt-item">
                                    <input type="radio" class="theme-rdo" value="Leather" name="sleeveOption" id="sleeveOption2">
                                    <label for="sleeveOption2" class="btn btn-dark btn-73">Classic</label>
                                </span>
                            </div>
                            <div class="col-lg-3 pl-0">
                                <button class="btn btn-success btn-sm btn-block btnBack">Back</button>
                                <button class="btn btn-success btn-sm btn-block btnNext">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>