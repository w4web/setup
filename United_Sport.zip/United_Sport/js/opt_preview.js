jQuery(document).ready(function () {

  $(document).on("change", ".sleeveColor", function () {
    $(".part.sleeve svg path").css("fill", $(this).val());
  });

  $(document).on("change", ".bodyColor", function () {
    $(".part.body svg path").css("fill", $(this).val());
  });

  $(document).on("change", ".wool-opt-rdo", function () {

    if ($(this).attr("value") == "Same") {
      $('#stNext2').show();
      $('#stNext3').hide();
    } 
    if ($(this).attr("value") == "Different") {
      $('#stNext3').show();
      $('#stNext2').hide();
    } 

  });

  $(document).on("change", ".collar-style-rdo", function () {

    if ($(this).attr("value") == "Knit") {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-1").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-1").addClass("active");

      $('#csNext2').hide();
      $('#csNext1').show();
    } 

    if ($(this).attr("value") == "Sport") {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-2").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-2").addClass("active");

      $('#csNext1').hide();
      $('#csNext2').show();
    } 

    if ($(this).attr("value") == "Zippered" || $(this).attr("value") == "Sailor" ) {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-3").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-3").addClass("active");

      $('#csNext1').hide();
      $('#csNext2').show();
    } 

  });

  $(document).on("change", ".uc-opt-rdo", function () {

    if ($(this).attr("value") == "Same") {
      $('#ucNext1').show();
      $('#ucNext2').hide();
    } 
    if ($(this).attr("value") == "Leather" || $(this).attr("value") == "Alternate") {
      $('#ucNext2').show();
      $('#ucNext1').hide();
    } 

  });

  $(document).on("change", ".shoulder-stripes-rdo", function () {

    if ($(this).attr("value") == "none") {
      $('#ssoNext1').show();
      $('#ssoNext2').hide();
    } 
    if ($(this).attr("value") == "Leather" || $(this).attr("value") == "Wool") {
      $('#ssoNext2').show();
      $('#ssoNext1').hide();
    } 

  });

  // Is wool or lether

  $(document).on("change", ".sleeve-type-rdo", function () {

    if ($(this).attr("value") == "Wool") {
      $('.isWool').show();
      $('.noWool').hide();
    } 
    if ($(this).attr("value") == "Leather") {
      $('.noWool').show();
      $('.isWool').hide();
    } 

  });








});
