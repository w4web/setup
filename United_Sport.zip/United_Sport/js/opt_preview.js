jQuery(document).ready(function () {

  $(document).on("change", ".sleeveColor", function () {
    $(".part.sleeve svg path").css("fill", $(this).val());
  });

  $(document).on("change", ".bodyColor", function () {
    $(".part.body svg path").css("fill", $(this).val());
  });

  $(document).on("change", ".collar-style-rdo", function () {

    if ($(this).attr("value") == "Knit") {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-1").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-1").addClass("active");
    } 

    if ($(this).attr("value") == "Sport") {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-2").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-2").addClass("active");
    } 

    if ($(this).attr("value") == "Zippered" || $(this).attr("value") == "Sailor" ) {
      $(".collar-shadow").removeClass("active");
      $(".collar-shadow-3").addClass("active");
      $(".collar-inner").removeClass("active");
      $(".collar-inner-3").addClass("active");
    } 

  });

});
