
jQuery(document).ready(function () {

	$("#fistBack").prop("disabled", true);

	// Go back

	$(document).on("click", ".btnBack", function () {

		if ($(this).parents(".acc_card").find('.inner-option').length > 1) {

			if ($(this).parents(".acc_card").find('.inner-option').first().hasClass('active')) {

				$(this).parents(".acc_card").prev(".acc_card").find('.btnTrigger').trigger("click");

			} else {

				$(this).parents(".acc_card").find('.inner-option.active').removeClass('active').prev().addClass('active');

				if ($(this).parents(".acc_card").is(':first-child') && $(this).parents(".acc_card").find('.inner-option').first().hasClass('active')) {

					$("#fistBack").prop("disabled", true);

				}

			}

		} else {

			$(this).parents(".acc_card").prev(".acc_card").find('.btnTrigger').trigger("click");

		}

		// $(this).parents(".acc_card").prev(".acc_card").find('.btnTrigger').trigger("click");

	})

	// Go next

	$(document).on("click", ".btnNext", function () {

		$("#fistBack").prop("disabled", false);

		if ($(this).parents(".acc_card").find('.inner-option').length > 1) {

			if ($(this).parents(".acc_card").find('.inner-option').last().hasClass('active')) {

				$(this).parents(".acc_card").next(".acc_card").find('.btnTrigger').trigger("click");

			} else {

				$(this).parents(".acc_card").find('.inner-option.active').removeClass('active').next().addClass('active');

			}

		} else {

			$(this).parents(".acc_card").next(".acc_card").find('.btnTrigger').trigger("click");

		}


	});


	function getData() {
		try {
			$.ajax({
				url: 'data/commonColors.json',
				dataType: "json",
				type: "GET",
				headers: {
					'Content-Type': 'application/json'
				},
				beforeSend: function () {

				},
				success: function (data) {
					console.log(data);
				},
				complete: function () {

				},
				error: function (e) {
					console.log('error', e);
					errorHandle(e);
				}
			});
		}
		catch (e) {
			console.log(e);
		}
	}

	function errorHandle(e) {
		if (e.status == 404) {
			$('.all-errors').html("<div class='alert alert-danger'>page not found</div>");
		}
	}

	getData();




});