
jQuery(document).ready(function () {

	$("#fistBack").prop("disabled", true);

	$(".btnNext").prop("disabled", true);
	$(".innerNext").prop("disabled", true);

	$('.theme-rdo').prop("checked", false);

	// Enable Back

	$(document).on("change", ".theme-rdo", function () {
		$(this).parents(".opt-row").find('.btnNext').prop("disabled", false);
		$(this).parents(".opt-row").find('.innerNext').prop("disabled", false);
	});

	// Step logics

	$(document).on("click", ".innerNext", function () {

		$(this).parents('.inner-option.active').removeClass('active').next().addClass('active');

	});

	$(document).on("click", ".innerBack", function () {

		$(this).parents('.inner-option.active').removeClass('active').prev().addClass('active');

	});

	// Tree logic 

	// Next ----------

	// For Sleeve Type

	$(document).on("click", "#stNext1", function () {

		if ($("#sleeveType1").is(':checked')) {
			$(".st-level-1").removeClass("active");
			$("#st-level-1-1").addClass("active");
			$("#st-parent").hide();
		}
		if ($("#sleeveType2").is(':checked')) {
			$(".st-level-1").removeClass("active");
			$("#st-level-1-2").addClass("active");
			$("#st-parent").hide();
		}

	});

	// For Collar style

	$(document).on("click", "#csNext2", function () {

		if ($("#collarStyle1").is(':checked')) {
			$(".cs-level-1").removeClass("active");
		}
		if ($("#collarStyle2").is(':checked')) {
			$(".cs-level-1").removeClass("active");
			$("#cs-level-1-1").addClass("active");
			$("#cs-parent").hide();
		}
		if ($("#collarStyle3").is(':checked')) {
			$(".cs-level-1").removeClass("active");
			$("#cs-level-1-2").addClass("active");
			$("#cs-parent").hide();
		}
		if ($("#collarStyle4").is(':checked')) {
			$(".cs-level-1").removeClass("active");
			$("#cs-level-1-3").addClass("active");
			$("#cs-parent").hide();
		}

	});

	// For Trim Pattern

	$(document).on("click", "#tpNext1", function () {

		if ($("#trimPattern1").is(':checked')) {
			$(".tp-level-1").removeClass("active");
			$("#tp-level-1-1").addClass("active");
			$("#tp-parent").hide();
		}
		if ($("#trimPattern2").is(':checked')) {
			$(".tp-level-1").removeClass("active");
			$("#tp-level-1-2").addClass("active");
			$("#tp-parent").hide();
		}
		if ($("#trimPattern3").is(':checked')) {
			$(".tp-level-1").removeClass("active");
			$("#tp-level-1-3").addClass("active");
			$("#tp-parent").hide();
		}

	});

	// For Shoulder Stripes count hide

	$(document).on("click", "#ssoNext2", function () {

		if ($("#ssopt1").is(':checked')) {
			$("#sscItem3").show();
		}
		if ($("#ssopt2").is(':checked')) {
			$("#sscItem3").hide();
		}

	});

	


	// Back

	$(document).on("click", ".stBack", function () {
		$(".st-level-1").removeClass("active");
		$("#st-parent").show();
	});

	$(document).on("click", ".csBack", function () {
		$(".cs-level-1").removeClass("active");
		$("#cs-parent").show();
	});

	$(document).on("click", ".tpBack", function () {
		$(".tp-level-1").removeClass("active");
		$("#tp-parent").show();
	});



});