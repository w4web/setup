
jQuery(document).ready(function () {

	$("#fistBack").prop("disabled", true);
	$(".btnNext").prop("disabled", true);
	$('.theme-rdo').prop("checked", false);

	// Go back

	$(document).on("click", ".btnBack", function () {

		if ($(this).parents(".acc_card").find('.inner-option').length > 1) {

			if ($(this).parents(".acc_card").find('.inner-option').first().hasClass('active')) {

				$(this).parents(".acc_card").prev(".acc_card").find('.btnTrigger').trigger("click");

			} else {

				$(this).parents(".acc_card").find('.inner-option.active').removeClass('active').prev().addClass('active');

				if ($(this).parents(".acc_card").is(':first-child') && $(this).parents(".acc_card").find('.inner-option').first().hasClass('active')) {

					$("#fistBack").prop("disabled", true);

				}

			}

		} else {

			$(this).parents(".acc_card").prev(".acc_card").find('.btnTrigger').trigger("click");

		}

	})

	// Go next

	$(document).on("click", ".btnNext", function () {

		$("#fistBack").prop("disabled", false);

		if ($(this).parents(".acc_card").find('.inner-option').length > 1) {

			if ($(this).parents(".acc_card").find('.inner-option').last().hasClass('active')) {

				$(this).parents(".acc_card").next(".acc_card").find('.btnTrigger').trigger("click");

			} else {

				$(this).parents(".acc_card").find('.inner-option.active').removeClass('active').next().addClass('active');

			}

		} else {

			$(this).parents(".acc_card").next(".acc_card").find('.btnTrigger').trigger("click");

		}


	});


	// Enable Back

	$(document).on("change", ".theme-rdo", function () {
		$(this).parents(".opt-row").find('.btnNext').prop("disabled", false);
	});




});