
jQuery(document).ready(function () {

    // Responsive menu

    $('.main-menu li').each(function () {

        if ($(this).find('ul').length > 0) {
            $(this).prepend("<a class='open-close' href='javascript:void(0);'><i class='fa fa-angle-down'></i></a>");
        }

    });


    $('.open-close').on('click', function () {
        $(this).parent('li').siblings().find('ul').slideUp("fast");
        $(this).siblings('ul').slideToggle("fast");

        $(this).parent('li').siblings().removeClass('active');
        $(this).parent('li').toggleClass('active');

    });


    $('.menu-handler').on('click', function () {
        $('.main-menu').slideToggle('fast');
    });

});