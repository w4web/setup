jQuery(document).ready(function () {

	// Get json data

	function getData(dataUrl) {

		var myData = null;

		try {
			$.ajax({
				url: dataUrl,
				dataType: "json",
				async: false,
				type: "GET",
				headers: {
					'Content-Type': 'application/json'
				},
				beforeSend: function () {

				},
				success: function (data) {
					myData = data;
				},
				complete: function (data) {
					
				},
				error: function (e) {
					console.log('error', e);
					errorHandle(e);
				}
			});
		}
		catch (e) {
			console.log(e);
		}

		return myData;
	}

	function errorHandle(e) {
		if (e.status == 404) {
			$('.all-errors').html("<div class='alert alert-danger'>page not found</div>");
		}
	}

	// Call Ajax

	var sleeveColors = getData('data/sleeveColors.json');
	var bodyColors = getData('data/bodyColors.json');


	// Sleeve color data

	let sleeveOpt = '';

	for (let color of sleeveColors) {
		sleeveOpt += '<span class="color-option">';
		sleeveOpt += '<input type="radio" class="theme-rdo sleeveColor" value="' + color.colorCode + '" name="sleeveOptions" id="sleeveOpt' + color.id + '">';
		sleeveOpt += '<label style="background-color: ' + color.colorCode + '" for="sleeveOpt' + color.id + '"></label>';
		sleeveOpt += '</span>';
	}

	$('.sleeve-color-options').append(sleeveOpt);

	// ----------------

	// Body color data

	let bodyOpt = '';

	for (let color of bodyColors) {
		bodyOpt += '<span class="color-option">';
		bodyOpt += '<input type="radio" class="theme-rdo bodyColor" value="' + color.colorCode + '" name="bodyOptions" id="bodyOpt' + color.id + '">';
		bodyOpt += '<label style="background-color: ' + color.colorCode + '" for="bodyOpt' + color.id + '"></label>';
		bodyOpt += '</span>';
	}

	$('.body-color-options').append(bodyOpt);

	// ----------------




	
                                
                                
                            

	

});