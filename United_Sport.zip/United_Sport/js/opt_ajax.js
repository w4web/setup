jQuery(document).ready(function () {

	// Get json data

	function getData(dataUrl) {

		var myData = null;

		try {
			$.ajax({
				url: dataUrl,
				dataType: "json",
				async: false,
				type: "GET",
				headers: {
					'Content-Type': 'application/json'
				},
				beforeSend: function () {

				},
				success: function (data) {
					myData = data;
				},
				complete: function (data) {
					
				},
				error: function (e) {
					console.log('error', e);
					errorHandle(e);
				}
			});
		}
		catch (e) {
			console.log(e);
		}

		return myData;
	}

	function errorHandle(e) {
		if (e.status == 404) {
			$('.all-errors').html("<div class='alert alert-danger'>page not found</div>");
		}
	}

	// Call Ajax

	var sleeveColors = getData('data/sleeveColors.json');
	var bodyColors = getData('data/bodyColors.json');
	var undercollarColors = getData('data/undercollarColors.json');
	var hoodColors = getData('data/hoodColors.json');
	var braidColors = getData('data/braidColors.json');
	var baseColors = getData('data/baseColors.json');
	var stripeColors = getData('data/stripeColors.json');

	var ss1Colors = getData('data/shoulderStripe1Colors.json');
	var ss2Colors = getData('data/shoulderStripe2Colors.json');



	// Sleeve color data

	let sleeveOpt = '';

	for (let color of sleeveColors) {
		sleeveOpt += '<span class="color-option">';
		sleeveOpt += '<input type="radio" class="theme-rdo sleeveColor" value="' + color.colorCode + '" name="sleeveOptions" id="sleeveOpt' + color.id + '">';
		sleeveOpt += '<label style="background-color: ' + color.colorCode + '" for="sleeveOpt' + color.id + '"></label>';
		sleeveOpt += '</span>';
	}

	$('.sleeve-color-options').append(sleeveOpt);

	// ----------------

	// Body color data

	let bodyOpt = '';

	for (let color of bodyColors) {
		bodyOpt += '<span class="color-option">';
		bodyOpt += '<input type="radio" class="theme-rdo bodyColor" value="' + color.colorCode + '" name="bodyOptions" id="bodyOpt' + color.id + '">';
		bodyOpt += '<label style="background-color: ' + color.colorCode + '" for="bodyOpt' + color.id + '"></label>';
		bodyOpt += '</span>';
	}

	$('.body-color-options').append(bodyOpt);

	// ----------------

	// Undercollar color data

	let undercollarOpt = '';

	for (let color of undercollarColors) {
		undercollarOpt += '<span class="color-option">';
		undercollarOpt += '<input type="radio" class="theme-rdo undercollarColor" value="' + color.colorCode + '" name="undercollarOptions" id="undercollarOpt' + color.id + '">';
		undercollarOpt += '<label style="background-color: ' + color.colorCode + '" for="undercollarOpt' + color.id + '"></label>';
		undercollarOpt += '</span>';
	}

	$('.undercollar-color-options').append(undercollarOpt);

	// ----------------

	// Hood color data

	let hoodOpt = '';

	for (let color of hoodColors) {
		hoodOpt += '<span class="color-option">';
		hoodOpt += '<input type="radio" class="theme-rdo hoodColor" value="' + color.colorCode + '" name="hoodOptions" id="hoodOpt' + color.id + '">';
		hoodOpt += '<label style="background-color: ' + color.colorCode + '" for="hoodOpt' + color.id + '"></label>';
		hoodOpt += '</span>';
	}

	$('.hood-color-options').append(hoodOpt);

	// ----------------

	// Sailor Hood color data

	let shoodOpt = '';

	for (let color of hoodColors) {
		shoodOpt += '<span class="color-option">';
		shoodOpt += '<input type="radio" class="theme-rdo shoodColor" value="' + color.colorCode + '" name="shoodOptions" id="shoodOpt' + color.id + '">';
		shoodOpt += '<label style="background-color: ' + color.colorCode + '" for="shoodOpt' + color.id + '"></label>';
		shoodOpt += '</span>';
	}

	$('.s-hood-color-options').append(shoodOpt);

	// ----------------

	// Braid color data

	let braidOpt = '';

	for (let color of braidColors) {
		braidOpt += '<span class="color-option">';
		braidOpt += '<input type="radio" class="theme-rdo braidColor" value="' + color.colorCode + '" name="braidOptions" id="braidOpt' + color.id + '">';
		braidOpt += '<label style="background-color: ' + color.colorCode + '" for="braidOpt' + color.id + '"></label>';
		braidOpt += '</span>';
	}

	$('.braid-color-options').append(braidOpt);

	// ----------------

	// Base color data

	let baseOpt = '';

	for (let color of baseColors) {
		baseOpt += '<span class="color-option">';
		baseOpt += '<input type="radio" class="theme-rdo baseColor" value="' + color.colorCode + '" name="baseOptions" id="baseOpt' + color.id + '">';
		baseOpt += '<label style="background-color: ' + color.colorCode + '" for="baseOpt' + color.id + '"></label>';
		baseOpt += '</span>';
	}

	$('.base-color-options').append(baseOpt);

	// --------

	let base2Opt = '';

	for (let color of baseColors) {
		base2Opt += '<span class="color-option">';
		base2Opt += '<input type="radio" class="theme-rdo base2Color" value="' + color.colorCode + '" name="base2Options" id="base2Opt' + color.id + '">';
		base2Opt += '<label style="background-color: ' + color.colorCode + '" for="base2Opt' + color.id + '"></label>';
		base2Opt += '</span>';
	}

	$('.base2-color-options').append(base2Opt);

	// --------

	let base3Opt = '';

	for (let color of baseColors) {
		base3Opt += '<span class="color-option">';
		base3Opt += '<input type="radio" class="theme-rdo base3Color" value="' + color.colorCode + '" name="base3Options" id="base3Opt' + color.id + '">';
		base3Opt += '<label style="background-color: ' + color.colorCode + '" for="base3Opt' + color.id + '"></label>';
		base3Opt += '</span>';
	}

	$('.base3-color-options').append(base3Opt);

	// ----------------

	// Stripe color data

	let stripe1Opt = '';

	for (let color of stripeColors) {
		stripe1Opt += '<span class="color-option">';
		stripe1Opt += '<input type="radio" class="theme-rdo stripe1Color" value="' + color.colorCode + '" name="stripe1Options" id="stripe1Opt' + color.id + '">';
		stripe1Opt += '<label style="background-color: ' + color.colorCode + '" for="stripe1Opt' + color.id + '"></label>';
		stripe1Opt += '</span>';
	}

	$('.stripe1-color-options').append(stripe1Opt);

	// --------

	let stripe2Opt = '';

	for (let color of stripeColors) {
		stripe2Opt += '<span class="color-option">';
		stripe2Opt += '<input type="radio" class="theme-rdo stripe2Color" value="' + color.colorCode + '" name="stripe2Options" id="stripe2Opt' + color.id + '">';
		stripe2Opt += '<label style="background-color: ' + color.colorCode + '" for="stripe2Opt' + color.id + '"></label>';
		stripe2Opt += '</span>';
	}

	$('.stripe2-color-options').append(stripe2Opt);

	// Shoulder Stripe color data

	let ss1Opt = '';

	for (let color of ss1Colors) {
		ss1Opt += '<span class="color-option">';
		ss1Opt += '<input type="radio" class="theme-rdo ss1Color" value="' + color.colorCode + '" name="ss1Options" id="ss1Opt' + color.id + '">';
		ss1Opt += '<label style="background-color: ' + color.colorCode + '" for="ss1Opt' + color.id + '"></label>';
		ss1Opt += '</span>';
	}

	$('.ss1-color-options').append(ss1Opt);

	// --------

	// Shoulder Stripe color data

	let ss2Opt = '';

	for (let color of ss2Colors) {
		ss2Opt += '<span class="color-option">';
		ss2Opt += '<input type="radio" class="theme-rdo ss2Color" value="' + color.colorCode + '" name="ss2Options" id="ss2Opt' + color.id + '">';
		ss2Opt += '<label style="background-color: ' + color.colorCode + '" for="ss2Opt' + color.id + '"></label>';
		ss2Opt += '</span>';
	}

	$('.ss2-color-options').append(ss2Opt);

	// --------




	
                                
                                
                            

	

});