<?php include 'header.php'; ?>

<div class="main-content pt-5">

	<div class="container">
		<div class="all-errors"></div>
		<div class="page-card">
			<div class="row">
				<div class="col-lg-4">
					<?php include 'sidebar.php'; ?>
				</div>
				<div class="col-lg-8">
					<?php include 'jacket_preview.php'; ?>
				</div>
			</div>
		</div>
	</div>

</div>

<?php include 'footer.php'; ?>