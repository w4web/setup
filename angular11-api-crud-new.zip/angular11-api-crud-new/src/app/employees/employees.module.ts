import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeesRoutingModule } from './employees-routing.module';
import { EmployeesComponent } from './employees.component';
import { ListComponent } from './list/list.component';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { SharedModule } from '../shared/shared.module';
import { FileUploadModule } from 'ng2-file-upload';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [EmployeesComponent, ListComponent, AddComponent, EditComponent],
  imports: [
    CommonModule,
    EmployeesRoutingModule,
    SharedModule,
    FileUploadModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class EmployeesModule { }
