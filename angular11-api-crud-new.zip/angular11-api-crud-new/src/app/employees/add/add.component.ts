import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/shared/services/auth/auth.service';
import { CommonService } from 'src/app/shared/services/common.service';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

const uploadAPI = 'http://192.168.15.122/wordpress-Rest-API/wp-json/wp/v2/media';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})

export class AddComponent implements OnInit {

  // model: NgbDateStruct;

  public currentUser;
  public uploader: FileUploader;

  postData = {
    name: '',
    mobile: '',
    email: '',
    profile_pic: '',
    dob: '',
    status: 'publish'
  }

  postForm = this.formBuilder.group({
    name: ['', Validators.required],
    mobile: ['', Validators.required],
    email: ['', Validators.required],
    dob: ['', Validators.required]
  });

  constructor(private authService: AuthService, public commonService: CommonService, private formBuilder: FormBuilder) {

    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      console.log(this.currentUser);
      if (this.currentUser) {
        this.uploader = new FileUploader({ url: uploadAPI, itemAlias: 'file', authToken: 'Bearer ' + this.currentUser.token });
      }
    });

  }

  ngOnInit() {
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('FileUpload:uploaded successfully:', JSON.parse(response));
      this.postData.profile_pic = JSON.parse(response).source_url;
    };
  }

  onSubmit() {

    this.postData.name = this.postForm.value.name;
    this.postData.mobile = this.postForm.value.mobile;
    this.postData.email = this.postForm.value.email;
    this.postData.dob = JSON.stringify(this.postForm.value.dob);
    if (this.postData.profile_pic !== '') {
      this.commonService.addPost(this.postData)
    }
    console.log('Final data', this.postData);
    this.postForm.reset();
  }

}
