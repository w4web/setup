<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress-Rest-API' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'O|F#,CpPd-bT/E.#e%%h$W0GcQlo@ShrNJRG>:V2dSmfzz/)_hlIGBs*GTUl[WB9' );
define( 'SECURE_AUTH_KEY',  'MXdCCh%L4j}vIxHN+|m!|{vwKU:C;t/.pg$I@& sG&*|#8^%9g)Zp*#)i|CjV;8v' );
define( 'LOGGED_IN_KEY',    '{ZcxDcHo$*r.iiMv_f1XUlL>R)zb^ yG@>)x[Eha`08(D`:.CuKc*[1GRPEBT-8c' );
define( 'NONCE_KEY',        'X(dKq$5j9YTp_gnMIJmnx)Yo0:<Yj5hzP6ZS0Z}3rjAuO:H&yiKFQ_]WQUFCT?~V' );
define( 'AUTH_SALT',        '*L~^@@/7o,Tji6l,x7t_v<CTcZZa[JQseApTn1a~lH{h%k*jpYwrkbfrcLeMYVji' );
define( 'SECURE_AUTH_SALT', 'zk|]t#SExN;GR}+VQ8]@h4nS>YHk=dk4 eO83h^3W!-_L]/JJ5BjE)UBr/*g2mJ^' );
define( 'LOGGED_IN_SALT',   '8r4 u4r[=c)~lsdUMM}E.,t!X21S1~/b5+/2vkw25oxfJ(7?m8cr%i:#b>Bs0jVM' );
define( 'NONCE_SALT',       '1h):x(Srb>j>iv$gw|t&tqy)>Q1tGA^0L]y}<KK}+`3=~ g0t$iX0CXLo/ bi/zD' );

define('JWT_AUTH_SECRET_KEY', 'T^-jdUnRg9+f&G?5Z!y,)I Z(,B^_]LNQu+Jc<EeMxi9j9I~1+kD.keMGJ^6pxjl');
define('JWT_AUTH_CORS_ENABLE', true);

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
