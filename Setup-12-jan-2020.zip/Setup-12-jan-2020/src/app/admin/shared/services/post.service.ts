import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, from, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Router, Resolve } from '@angular/router';
import { AuthService } from './auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  public allPost;
  public posts$ = new BehaviorSubject(undefined);
  private data_Api = environment.dataApi;
  public currentUser;
  public commonHttpOptions;

  constructor(private http: HttpClient, private router: Router, private authService: AuthService) {

    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      console.log(this.currentUser);
      if (this.currentUser) {
        this.commonHttpOptions = {
          headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.currentUser.token}` })
        };
      }
    });

    this.getPost();

  }

  getPost() {
    this.http.get<any>(`${this.data_Api}/posts?_embed`).subscribe(data => {
      this.allPost = data;
      if(this.allPost) {
        this.posts$.next(this.allPost);
      }
    })
  }

  getSinglePost(id) {
    return this.http.get<any>(`${this.data_Api}/posts/${id}?_embed`);
  }

  addPost(data: any) {
    this.http.post<any>(`${this.data_Api}/posts`, data, this.commonHttpOptions).subscribe(
      (res) => {
        console.log('Post added data', res);
        this.getPost();
      },
      err => console.log(err)
    );
  }

  editPost(data: any, id: any) {
    this.http.post<any>(`${this.data_Api}/posts/${id}`, data, this.commonHttpOptions).subscribe(
      (res) => {
        console.log('Post Edited data', res);
        this.getPost();
      },
      err => console.log(err)
    );
  }

  deletePost(id: any) {
    this.http.delete<any>(`${this.data_Api}/posts/${id}`, this.commonHttpOptions).subscribe(
      (res) => {
        console.log('Post Deleted data', res);
        this.getPost();
      },
      err => console.log(err)
    );
  }



}
