import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { AdminComponent } from './admin.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './shared/services/auth/guard/auth.guard';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '', component: AdminComponent, canActivate: [AuthGuard], children: [
      { path: '', redirectTo: '/admin/home', pathMatch: 'full' },
      { path: 'home', component: HomeComponent },
      { path: 'users', component: UserListComponent },
      { path: 'posts', loadChildren: './components/post/post.module#PostModule'},
      { path: '**', component: PageNotFoundComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
