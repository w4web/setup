import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import * as utf8 from 'crypto-js/enc-utf8';
import * as AES from 'crypto-js/aes';
import { environment } from '../../../../environments/environment';
import { Router, Resolve } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth/auth.service';
import { FileUploader } from 'ng2-file-upload';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private base_Url = environment.baseUrl;
  private user_Api = environment.userApi;
  private data_Api = environment.dataApi;
  private api_key = environment.apiKey;

  public user;
  public user$ = new BehaviorSubject(undefined);

  public userDetail;
  public userDetail$ = new BehaviorSubject(undefined);

  public currentUser;
  public commonHttpOptions;
  public uploader: FileUploader;

  constructor(private http: HttpClient, private router: Router, private authService: AuthService) {

    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      console.log(this.currentUser);
      if (this.currentUser) {
        this.commonHttpOptions = {
          headers: new HttpHeaders({ 'Authorization': `Bearer ${this.currentUser.token}` })
        };

        // File Upload

        this.uploader = new FileUploader({ url: `${this.data_Api}/media`, itemAlias: 'file', authToken: 'Bearer ' + this.currentUser.token });
      
      }
    });

    this.getUserdetail();
    
  }

  getUserdetail() {
    this.http.get<any>(`${this.base_Url}/wp-json/wp/v2/users/me`, this.commonHttpOptions).subscribe(
      (res) => {
        this.userDetail = res;
        this.userDetail$.next(this.userDetail);
      },
      err => console.log(err)
    );
  }

  updateUser(data: any) {
    this.http.post<any>(`${this.base_Url}/wp-json/wp/v2/users/me`, data, this.commonHttpOptions).subscribe(
      (res) => {
        this.userDetail = res;
        this.userDetail$.next(this.userDetail);
      },
      err => console.log(err)
    );
  }

}
