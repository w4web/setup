import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Router, Resolve } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  private data_Api = environment.dataApi;

  posts = [];

  totalPost;
  totalPages;
  totalPagesNum = [];

  currentPage = 1;
  postPerPage = 6;

  search:string = '';

  public categories = [];
  public categoryIds = [1];

  constructor(private http: HttpClient, private router: Router) {
    this.getPost(this.currentPage, this.postPerPage, this.categoryIds);
    this.getCategories();
  }

  getPostByCat(id) {
    this.currentPage = 1;
    this.categoryIds = [];
    this.categoryIds.push(id);
    this.getPost(this.currentPage, this.postPerPage, this.categoryIds);
  }

  getCategories() {
    
    this.http.get<any>(`${this.data_Api}/categories`).subscribe((res:any) => {
      this.categories = res;
      console.log(res);
    })

  }

  getPost(cp, pp, cid) {
    this.http.get<any>(`${this.data_Api}/posts?_embed&per_page=${pp}&page=${cp}&categories=${cid}`, {observe: 'response'}).subscribe(
      (res) => {
        this.posts = res.body;
        this.totalPost = res.headers.get('X-WP-Total');
        this.totalPages = res.headers.get('X-WP-TotalPages');
        // console.log(res.body);
        this.totalPagesNum = [];
        for(let i = 1; i <= this.totalPages; i++) {
          this.totalPagesNum.push(i);
        }
      }, 
      err => {console.log(err)});

      this.currentPage = cp;
  }

  prevPage() {
    if(this.currentPage > 1) {

      this.currentPage = this.currentPage - 1;
      this.getPost(this.currentPage, this.postPerPage, this.categoryIds);

    }
  }

  nextPage() {
    if(this.currentPage < this.totalPages) {

      this.currentPage = this.currentPage + 1;
      this.getPost(this.currentPage, this.postPerPage, this.categoryIds);

    }
  }

  getSinglePost(id) {
    return this.http.get<any>(`${this.data_Api}/posts/${id}?_embed`);
  }

  getComments(id) {
    return this.http.get<any>(`${this.data_Api}/comments?post=${id}`);
  }

}
