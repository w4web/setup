import { Component, OnInit } from '@angular/core';
import { animations } from '../shared/animations/animations';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
  animations: [animations.fadeAnimation] 
})
export class UserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
