import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user.service';
import { FileUploader } from 'ng2-file-upload';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  public userDetail;
  public editEnable: boolean = false;

  userData = {
    first_name: '',
    last_name: '',
    description: '',
    url: '',
  }

  constructor(public userService: UserService, private formBuilder: FormBuilder) { }

  userForm = this.formBuilder.group({
    first_name: ['', Validators.required],
    last_name: ['', Validators.required],
    description: ['', Validators.required]
  });

  ngOnInit() {

    this.userService.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.userService.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('FileUpload:uploaded successfully:', response);
      this.userData.url = JSON.parse(response).source_url;
      // console.log(JSON.parse(response));
    };

    this.userService.userDetail$.subscribe(res => {

      this.userDetail = res;
      console.log('Full user detail..', res);

    }, err => console.log(err))

  }

  onSubmit() {
    this.userData.first_name = this.userForm.value.first_name;
    this.userData.last_name = this.userForm.value.last_name;
    this.userData.description = this.userForm.value.description;

    if (this.userData.url !== '') {
      this.userService.updateUser(this.userData)
    }

    this.userForm.reset();
    this.editEnable = false;
  }

}
