import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/services/auth/auth.service';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../shared/services/common.service';
import { Router, Resolve } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  error: string = "";
  success: string = "";

  constructor(public commonService: CommonService, public authService: AuthService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
  }

  signUpData = {
    username: '',
    email: '',
    password: ''
  }

  signUpForm = this.formBuilder.group({
    username: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
    confirmPassword: ['', Validators.required],
  });

  onSubmit() {

    this.error = "";
    this.success = "";

    if (this.signUpForm.value.password !== this.signUpForm.value.confirmPassword) {
      this.error = "Passwords do not match";
    } else {

      this.signUpData.username = this.signUpForm.value.username;
      this.signUpData.email = this.signUpForm.value.email;
      this.signUpData.password = this.signUpForm.value.password;

      this.authService.signUp(this.signUpData)
        .subscribe((res) => {
          console.log('Sign Un data', res)
        }, errMsg => {
          this.error = errMsg;
        }, () => {
          this.success = "User is registered successfully";
          this.signUpForm.reset();
        }
        );

    }

  }

}
