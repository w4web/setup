import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/services/auth/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  menuShow: boolean = false;
  menuItemShow: boolean = false;

  userLoggedIn: boolean = false;
  currentUser;

  constructor(private authService: AuthService) {

    this.authService.user$.subscribe(user => {
      this.userLoggedIn = user ? true : false;
      this.currentUser = user;
      // console.log(this.currentUser)
    });

  }

  ngOnInit() {
  }

  onTriggerClick() {
    this.menuShow = !this.menuShow;
  }
  onMenuClick() {
    if (window.innerWidth < 992) {
      this.menuItemShow = !this.menuItemShow;
    }
  }

}
