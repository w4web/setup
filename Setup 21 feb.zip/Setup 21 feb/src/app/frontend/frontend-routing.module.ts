import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { FrontendComponent } from './frontend.component';
import { PostComponent } from './components/post/post.component';
import { ContactComponent } from './components/contact/contact.component';
import { FaqComponent } from './components/faq/faq.component';
import { PostDetailComponent } from './components/post/post-detail/post-detail.component';
import { AuthGuard } from './shared/services/auth/guard/auth.guard';


const routes: Routes = [
  {
    path: '', component: FrontendComponent, children: [
      { path: 'user', loadChildren: './user/user.module#UserModule' },
      { path: '', redirectTo: '/home', pathMatch: 'full' },
      { path: 'home', component: HomeComponent },
      { path: 'post', component: PostComponent, canActivate: [AuthGuard] },
      { path: 'post-detail/:id', component: PostDetailComponent },
      { path: 'contact-us', component: ContactComponent },
      { path: 'faq', component: FaqComponent },
      { path: 'page-not-found', component: PageNotFoundComponent },
      { path: '**', redirectTo: '/page-not-found' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FrontendRoutingModule { }
