import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../shared/services/common.service';
import { AuthService } from '../../shared/services/auth/auth.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {

  constructor(public commonService: CommonService, public authService: AuthService, private formBuilder: FormBuilder) { }

  ngOnInit() {
  }

  signInData = {
    username: '',
    password: ''
  }

  signInForm = this.formBuilder.group({
    email: ['', Validators.required],
    password: ['', Validators.required],
  });

  onSubmit() {
    
    this.signInData.username = this.signInForm.value.email;
    this.signInData.password = this.signInForm.value.password;

    this.authService.signIn(this.signInData)
    this.signInForm.reset();
  }

}
