import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/services/auth/auth.service';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../shared/services/common.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  constructor(public commonService: CommonService, public authService: AuthService, private formBuilder: FormBuilder) { }

  ngOnInit() {
  }

  signUpData = {
    username: '',
    email: '',
    password: ''
  }

  signUpForm = this.formBuilder.group({
    username: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
  });

  onSubmit() {
    
    this.signUpData.username = this.signUpForm.value.username;
    this.signUpData.email = this.signUpForm.value.email;
    this.signUpData.password = this.signUpForm.value.password;

    this.authService.signUp(this.signUpData)
    this.signUpForm.reset();
  }

}
