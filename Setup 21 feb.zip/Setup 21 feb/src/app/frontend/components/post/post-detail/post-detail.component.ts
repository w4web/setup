import { Component, OnInit } from '@angular/core';
import { PostService } from '../../../shared/services/post.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.scss']
})
export class PostDetailComponent implements OnInit {

  public id;
  public singlePost;

  constructor( public postService: PostService, public route: ActivatedRoute ) { }

  ngOnInit() {

    this.id = this.route.snapshot.params.id;

    this.postService.getSinglePost(this.id).subscribe(data => {
      this.singlePost = data;
      console.log("single post", data);
    })

  }

}
