import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Router, Resolve } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  private data_Api = environment.dataApi;

  constructor(private http: HttpClient, private router: Router) {
    
  }

  getPost() {
    return this.http.get<any>(`${this.data_Api}/posts?_embed`);
  }

  getSinglePost(id) {
    return this.http.get<any>(`${this.data_Api}/posts/${id}?_embed`);
  }



}
