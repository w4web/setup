import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { tap } from 'rxjs/operators';
import * as utf8 from 'crypto-js/enc-utf8';
import * as AES from 'crypto-js/aes';
import { environment } from '../../../../../environments/environment';
import { Router, Resolve } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private user_Api = environment.userApi;
  private data_Api = environment.dataApi;
  private api_key = environment.apiKey;

  public user;
  public user$ = new BehaviorSubject(undefined);

  constructor(private http: HttpClient, private router: Router) {
    this.getStoredUser();
  }

  //encrypt(data, key), key could be any string. need same string in decrypt(data, key).

  storeUser(data) {
    const encrypted = AES.encrypt(
      JSON.stringify(data), this.api_key
    ).toString();
    sessionStorage.setItem('0', encrypted);
    this.user = data;
    this.user$.next(this.user);
  }

  getStoredUser() {
    if (sessionStorage.getItem('0')) {
      const userdata = sessionStorage.getItem('0');
      try {
        this.user = JSON.parse(
          AES.decrypt(userdata, this.api_key).toString(utf8)
        );
      } catch (err) {
        this.user = undefined;
        sessionStorage.removeItem('0');
      }
    } else {
      this.user = undefined;
      sessionStorage.removeItem('0');
    }
    this.user$.next(this.user);
    return this.user;
  }

  removeUser() {
    this.user = undefined;
    this.user$.next(this.user);
    sessionStorage.removeItem('0');
  }

  reCallUserSubscriber() {
    this.user$.next(this.user);
  }

  /* ------- API methods ------- */

  signUp(data: any) {

    this.http.post<any>(`${this.data_Api}/users/register`, data).pipe(
      tap((res: any) => {
        // if (res.idToken !== '') {
        //   this.storeUser(res);
        // }
        
      })
    ).subscribe((res) => { console.log('Sign Up data', res) }, err => console.log(err), () => this.router.navigate(['/post']));

  }

  signIn(data: any) {

    this.http.post<any>(`${this.user_Api}/token`, data).pipe(
      tap((res: any) => {
        if (res.token !== '') {
          this.storeUser(res);
        }
      })
    ).subscribe((res) => { console.log('Sign Up data', res) }, err => console.log(err), () => this.router.navigate(['/post']));

  }

  logOut() {
    this.removeUser();
    this.router.navigate(['/']);
  }

}
