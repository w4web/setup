import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from './components/loader/loader.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { NoAccessComponent } from './components/no-access/no-access.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';


@NgModule({
  declarations: [
    LoaderComponent,
    PageNotFoundComponent,
    NoAccessComponent
  ],
  imports: [
    CommonModule,
    AngularFontAwesomeModule
  ],
  exports: [
    LoaderComponent,
    PageNotFoundComponent,
    NoAccessComponent,
    AngularFontAwesomeModule
  ],
  providers: []
})
export class SharedModule { }
