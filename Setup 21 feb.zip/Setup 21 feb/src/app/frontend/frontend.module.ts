import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FrontendRoutingModule } from './frontend-routing.module';
import { SharedModule } from './shared/shared.module';
import { HomeComponent } from './components/home/home.component';
import { FrontendComponent } from './frontend.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { NguCarouselModule } from '@ngu/carousel';
import { PostComponent } from './components/post/post.component';
import { ContactComponent } from './components/contact/contact.component';
import { FaqComponent } from './components/faq/faq.component';
import { PostDetailComponent } from './components/post/post-detail/post-detail.component';

@NgModule({
  declarations: [
    HomeComponent,
    FrontendComponent,
    HeaderComponent,
    FooterComponent,
    PostComponent,
    ContactComponent,
    FaqComponent,
    PostDetailComponent
  ],
  imports: [
    CommonModule,
    FrontendRoutingModule,
    SharedModule,
    NguCarouselModule
  ]
})
export class FrontendModule { }
