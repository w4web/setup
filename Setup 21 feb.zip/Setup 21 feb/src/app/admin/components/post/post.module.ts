import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PostRoutingModule } from './post-routing.module';
import { AddPostComponent } from './add-post/add-post.component';
import { ListPostComponent } from './list-post/list-post.component';
import { EditPostComponent } from './edit-post/edit-post.component';
import { PostComponent } from './post.component';
import { MatButtonModule } from '@angular/material/button';
import {MatInputModule} from '@angular/material/input'; 
import { FileUploadModule } from 'ng2-file-upload';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [PostComponent, AddPostComponent, ListPostComponent, EditPostComponent],
  imports: [
    CommonModule,
    PostRoutingModule,
    MatButtonModule,
    MatInputModule,
    FileUploadModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class PostModule { }
