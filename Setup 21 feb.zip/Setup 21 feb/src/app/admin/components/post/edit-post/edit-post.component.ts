import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { AuthService } from 'src/app/admin/shared/services/auth/auth.service';
import { PostService } from 'src/app/admin/shared/services/post.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

const uploadAPI = 'http://192.168.15.122/wordpress-Rest-API/wp-json/wp/v2/media'; // better use a service class

@Component({
  selector: 'app-edit-post',
  templateUrl: './edit-post.component.html',
  styleUrls: ['./edit-post.component.scss']
})
export class EditPostComponent implements OnInit {

  public id;
  public singlePost;
  public currentUser;
  public uploader: FileUploader;

  postData = {
    title: '',
    content: '',
    featured_media: 0,
    status: 'publish'
  }

  postForm = this.formBuilder.group({
    title: ['', Validators.required],
    content: ['', Validators.required],
  });

  constructor(private authService: AuthService, public postService: PostService, private formBuilder: FormBuilder, public route: ActivatedRoute) {

    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      console.log(this.currentUser);
      if (this.currentUser) {
        this.uploader = new FileUploader({ url: uploadAPI, itemAlias: 'file', authToken: 'Bearer ' + this.currentUser.token });
      }
    });

  }

  ngOnInit() {
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('FileUpload:uploaded successfully:', response);
      this.postData.featured_media = JSON.parse(response).id;
    };

    this.id = this.route.snapshot.params.id;

    this.postService.getSinglePost(this.id).subscribe(data => {
      this.singlePost = data;
      console.log("single post", data);
    })
  }

  onSubmit() {

    this.postData.title = this.postForm.value.title;
    this.postData.content = this.postForm.value.content;
    if (this.postData.featured_media !== 0) {
      this.postService.editPost(this.postData, this.id)
    }
    this.postForm.reset();
  }

}
