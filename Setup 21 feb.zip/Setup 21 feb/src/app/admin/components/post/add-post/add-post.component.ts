import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { AuthService } from 'src/app/admin/shared/services/auth/auth.service';
import { PostService } from 'src/app/admin/shared/services/post.service';
import { FormBuilder, Validators } from '@angular/forms';

const uploadAPI = 'http://192.168.15.122/wordpress-Rest-API/wp-json/wp/v2/media'; // better use a service class

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.scss']
})
export class AddPostComponent implements OnInit {

  public currentUser;
  public uploader: FileUploader;

  postData = {
    title: '',
    content: '',
    featured_media: 0,
    status: 'publish'
  }

  postForm = this.formBuilder.group({
    title: ['', Validators.required],
    content: ['', Validators.required],
  });

  constructor(private authService: AuthService, public postService: PostService, private formBuilder: FormBuilder) {

    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      console.log(this.currentUser);
      if (this.currentUser) {
        this.uploader = new FileUploader({ url: uploadAPI, itemAlias: 'file', authToken: 'Bearer ' + this.currentUser.token });
      }
    });

  }

  ngOnInit() {
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      console.log('FileUpload:uploaded successfully:', response);
      this.postData.featured_media = JSON.parse(response).id;
    };
  }

  onSubmit() {

    this.postData.title = this.postForm.value.title;
    this.postData.content = this.postForm.value.content;
    if (this.postData.featured_media !== 0) {
      this.postService.addPost(this.postData)
    }
    this.postForm.reset();
  }

}
