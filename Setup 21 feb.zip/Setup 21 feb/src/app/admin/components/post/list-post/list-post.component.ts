import { Component, OnInit } from '@angular/core';
import { PostService } from 'src/app/admin/shared/services/post.service';

@Component({
  selector: 'app-list-post',
  templateUrl: './list-post.component.html',
  styleUrls: ['./list-post.component.scss', '../../../admin.component.scss']
})
export class ListPostComponent implements OnInit {

  posts = [];

  constructor( public postService: PostService ) { }

  ngOnInit() {

    this.postService.posts$.subscribe(data => {
      this.posts = data;
      console.log(data);
    })

  }

}
