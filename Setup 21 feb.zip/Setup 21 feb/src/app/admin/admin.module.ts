import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { HomeComponent } from './components/home/home.component';
import { SharedModule } from './shared/shared.module';
import { AdminComponent } from './admin.component';
import { HeaderComponent } from './common/header/header.component';

import {MatSidenavModule} from '@angular/material/sidenav'; 
import {MatToolbarModule} from '@angular/material/toolbar'; 
import {MatButtonModule} from '@angular/material/button'; 
import {MatIconModule} from '@angular/material/icon';
import {SidenavComponent} from './common/sidenav/sidenav.component'; 
import {MatDividerModule} from '@angular/material/divider'; 
import {MatListModule} from '@angular/material/list'; 
import {MatSortModule} from '@angular/material/sort'; 
import { MatTableModule } from '@angular/material/table';
import { UserListComponent } from './components/user-list/user-list.component';
import {MatCardModule} from '@angular/material/card';
import { LoginComponent } from './login/login.component'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    HomeComponent, 
    AdminComponent,
    HeaderComponent,
    SidenavComponent,
    UserListComponent,
    LoginComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
    MatSidenavModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    MatTableModule,
    MatSortModule,
    MatCardModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class AdminModule { }
